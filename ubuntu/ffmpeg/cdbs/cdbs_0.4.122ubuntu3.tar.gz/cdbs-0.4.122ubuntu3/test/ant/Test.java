public class Test {
	public int foo() {
		return 0;
	}
}
